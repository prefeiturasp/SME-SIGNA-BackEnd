from rest_framework import mixins, viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework.decorators import action

from apps.designacao.models.ato_administrativo import AtoAdministrativo
from apps.designacao.api.serializers.portaria_serializer import PortariaListSerializer
from apps.designacao.api.filters.portaria_filter import PortariaFilter


class PortariaListViewSet(
    mixins.ListModelMixin,
    viewsets.GenericViewSet
):
    """
    ViewSet para listagem de portarias (Designação, Cessação,
    Insubsistência, Apostila) conforme tela de publicação no D.O.

    Colunas exibidas:
        PORTARIA | DOC | TIPO DE ATO | NOME | CARGO | D.O |
        DATA DA DESIGNAÇÃO | DATA DA CESSAÇÃO | Nº SEI
    """

    serializer_class = PortariaListSerializer
    pagination_class = None

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PortariaFilter

    search_fields = [
        'numero_portaria',
        'designacao_detalhe__indicado_nome_servidor',
        'designacao_detalhe__indicado_nome_civil',
        'designacao_detalhe__indicado_rf',
    ]

    ordering_fields = [
        'numero_portaria',
        'designacao_detalhe__data_inicio',
        'designacao_detalhe__data_fim',
        'criado_em',
    ]

    ordering = ['numero_portaria']

    def get_queryset(self):
        return (
            AtoAdministrativo.objects
            .all()
            .select_related(
                'designacao_detalhe',
                'designacao_detalhe__impedimento_substituicao',
                'ato_pai__designacao_detalhe',
                'ato_raiz__designacao_detalhe',
            )
            .order_by('numero_portaria')
        )

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['post'], url_path='atualizar-data-publicacao')
    def atualizar_data_publicacao(self, request):
        # TO-DO: implementar após definição do campo de data de publicação
        return Response({'detail': 'Não implementado ainda.'}, status=501)