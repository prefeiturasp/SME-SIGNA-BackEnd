import django_filters
from apps.designacao.models.ato_administrativo import AtoAdministrativo


class PortariaFilter(django_filters.FilterSet):
    """
    Filtros da tela:
        - N° SEI da lauda definitiva
        - Portaria inicial / Portaria final
        - Ano
        - Listar para (tipo de ato)
    """

    numero_sei = django_filters.CharFilter(
        field_name='sei_numero',
        lookup_expr='icontains',
        label='Nº SEI da lauda definitiva',
    )

    portaria_inicial = django_filters.CharFilter(
        field_name='numero_portaria',
        lookup_expr='gte',
        label='Portaria inicial',
    )

    portaria_final = django_filters.CharFilter(
        field_name='numero_portaria',
        lookup_expr='lte',
        label='Portaria final',
    )

    ano = django_filters.CharFilter(
        field_name='ano_vigente',
        lookup_expr='iexact',
        label='Ano',
    )

    tipo = django_filters.ChoiceFilter(
        field_name='tipo',
        choices=AtoAdministrativo.Tipo.choices,
        label='Listar para (tipo de ato)',
    )

    class Meta:
        model = AtoAdministrativo
        fields = [
            'numero_sei',
            'portaria_inicial',
            'portaria_final',
            'ano',
            'tipo',
        ]