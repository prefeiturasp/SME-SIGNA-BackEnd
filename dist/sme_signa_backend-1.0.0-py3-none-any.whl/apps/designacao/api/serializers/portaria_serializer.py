from rest_framework import serializers
from apps.designacao.models.ato_administrativo import AtoAdministrativo


class PortariaListSerializer(serializers.ModelSerializer):
    """
    Serializer para a listagem de portarias na tela de publicação D.O.

    Colunas:
        PORTARIA | DOC | TIPO DE ATO | NOME | CARGO | D.O |
        DATA DA DESIGNAÇÃO | DATA DA CESSAÇÃO | Nº SEI
    """

    portaria   = serializers.CharField(source='numero_portaria')
    doc        = serializers.CharField(source='doc')
    tipo_de_ato = serializers.CharField(source='get_tipo_display')
    numero_sei = serializers.CharField(source='sei_numero')

    # Campos vindos do DesignacaoDetalhe (detalhe da designação raiz)
    nome               = serializers.SerializerMethodField()
    cargo              = serializers.SerializerMethodField()
    data_da_designacao = serializers.SerializerMethodField()
    data_da_cessacao   = serializers.SerializerMethodField()

    # D.O — campo a ser adicionado futuramente no model
    do = serializers.SerializerMethodField()

    class Meta:
        model = AtoAdministrativo
        fields = [
            'id',
            'portaria',
            'doc',
            'tipo_de_ato',
            'nome',
            'cargo',
            'do',
            'data_da_designacao',
            'data_da_cessacao',
            'numero_sei',
        ]

    def _get_detalhe(self, obj):
        """
        Retorna o DesignacaoDetalhe relevante:
        - Para DESIGNACAO: próprio detalhe
        - Para CESSACAO / APOSTILA / INSUBSISTENCIA: detalhe do ato raiz (designação original)
        """
        try:
            if obj.tipo == AtoAdministrativo.Tipo.DESIGNACAO:
                return obj.designacao_detalhe
            # Para os demais tipos, busca o detalhe do ato raiz
            raiz = obj.ato_raiz or obj.ato_pai
            if raiz:
                return raiz.designacao_detalhe
        except Exception:
            pass
        return None

    def get_nome(self, obj) -> str:
        detalhe = self._get_detalhe(obj)
        if not detalhe:
            return ''
        return detalhe.indicado_nome_servidor or detalhe.indicado_nome_civil or ''

    def get_cargo(self, obj) -> str:
        detalhe = self._get_detalhe(obj)
        if not detalhe:
            return ''
        return detalhe.indicado_cargo_sobreposto or detalhe.indicado_cargo_base or ''

    def get_data_da_designacao(self, obj):
        detalhe = self._get_detalhe(obj)
        if not detalhe:
            return None
        return detalhe.data_inicio

    def get_data_da_cessacao(self, obj):
        detalhe = self._get_detalhe(obj)
        if not detalhe:
            return None
        return detalhe.data_fim

    def get_do(self, obj):
        # TODO: retornar número do D.O. quando o campo for adicionado ao model
        return None